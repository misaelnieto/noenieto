# -*- coding: utf-8 -*-

from zope.component import getMultiAdapter

from Acquisition import aq_inner
from Products.CMFCore.utils import getToolByName
from Products.Five.browser.pagetemplatefile import ViewPageTemplateFile
from plone.app.layout.viewlets import ViewletBase

from collective.disqus.browser.configlet import IDisqusSettings
from collective.disqus.util import get_disqus_sso_message
from collective.disqus.userdata import IDisqusSSOUserDataProvider


class DisqusViewlet(ViewletBase):
    """
    Viewlet that for DISQUS comment system.
    """
    index = ViewPageTemplateFile("disqus_panel.pt")

    def update(self):
        """
        Update parameters used to render template.
        """
        super(DisqusViewlet, self).update()
        portal_membership = getToolByName(self.context,
                                          'portal_membership', None)
        portal_discussion = getToolByName(self.context,
                                          'portal_discussion', None)

        portal_url = getToolByName(self.context, 'portal_url')
        portal = portal_url.getPortalObject()
        self.settings = IDisqusSettings(portal)
        # display for this content item?
        is_discussion_allowed = False
        if portal_discussion is not None:
            is_discussion_allowed = \
                    portal_discussion.isDiscussionAllowedFor(
                        aq_inner(self.context))

        # display for this user?
        is_user_allowed = True
        if self.settings.anon_only:
            if not portal_membership.isAnonymousUser():
                is_user_allowed = False

        # set display condition
        self.condition = self.settings.forum_id and is_discussion_allowed and \
            is_user_allowed

        # prepare SSO related settings if needed
        self.purl = portal.absolute_url()

        # set defaults for js
        self.sso = self.own_login = 'false'
        self.app_secret_key = self.settings.app_secret_key
        self.app_public_key = self.settings.app_public_key
        self.sso_message = self.sso_button_url = self.sso_icon_url = ''
        self.sso_login_url = self.sso_logout_url = ''

        if self.settings.enable_sso:
            # secret and public keys are required minimum for sso integration
            if self.app_secret_key and self.app_public_key:
                self.sso = 'true'
                # we use IDisqusSSOUserProvider interface to allow 3rd parties
                # implement their own users and keep data whereever they need,
                # just by overriding their own adapter; meanwhile we provide
                # our own default one which works with standard Plone ZODB users
                user = getMultiAdapter((self.context, self.request),
                    IDisqusSSOUserDataProvider).getUserData()
                self.sso_message = get_disqus_sso_message(self.app_secret_key,
                    user)

                # now we also check if there is need to include our own
                # login/logout buttons into DISQUS form
                if self.settings.sso_site_name and self.settings.sso_login_url \
                   and self.settings.sso_logout_url:
                    pholders = {
                        'portal_url': self.purl,
                        'object_url': self.context.absolute_url()
                    }
                    self.own_login = 'true'
                    self.sso_button_url = self.settings.sso_button % pholders
                    self.sso_icon_url = self.settings.sso_icon % pholders
                    self.sso_login_url = self.settings.sso_login_url % pholders
                    self.sso_logout_url = self.settings.sso_logout_url % \
                        pholders

    def disqus_js(self):
        js = """
            if (%(enable_sso)s) {
              var disqus_config = function() {
                this.page.remote_auth_s3 = '%(sso_message)s';
                this.language = '%(language)s';
                this.page.api_key = '%(sso_public_key)s';
                if (%(own_login)s) {
                  this.sso = {
                    'name': '%(sso_site_name)s',
                    'button': '%(sso_button_url)s',
                    'icon': '%(sso_icon_url)s',
                    'url': '%(sso_login_url)s',
                    'logout': '%(sso_logout_url)s',
                    'width': '%(sso_width)s',
                    'height': '%(sso_height)s'
                 };
                }
              }
            } else {
              var disqus_config = function() {
                this.language = '%(language)s';
              }
            };
            var disqus_identifier = '%(disqus_identifier)s';
            var disqus_url = '%(disqus_url)s';
            var disqus_developer = %(disqus_developer)s;
            (function() {
             var dsq = document.createElement('script'); dsq.type = 'text/javascript'; dsq.async = true;
             dsq.src = 'http://%(disqus_id)s.disqus.com/embed.js';
             (document.getElementsByTagName('head')[0] || document.getElementsByTagName('body')[0]).appendChild(dsq);
            })();""" % dict(
                enable_sso = self.sso,
                sso_message = self.sso_message,
                sso_public_key = self.app_public_key,
                own_login = self.own_login,
                sso_site_name = self.settings.sso_site_name,
                sso_button_url = self.sso_button_url,
                sso_icon_url = self.sso_icon_url,
                sso_login_url = self.sso_login_url,
                sso_logout_url = self.sso_logout_url,
                sso_width = self.settings.sso_width,
                sso_height = self.settings.sso_height,
                disqus_identifier = self.context.UID(),
                disqus_url = self.context.absolute_url(),
                disqus_id = self.settings.forum_id,
                language = self.language(),
                disqus_developer = self.settings.dev_mode and 1 or 0)

        return js

    def language(self):
        state = getMultiAdapter((self.context, self.request),
                                name=u'plone_portal_state')
        return state.language()
