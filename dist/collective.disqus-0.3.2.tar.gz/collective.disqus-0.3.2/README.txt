Introduction
============

Integrates `DISQUS`_ comment system with `Plone`_.

Default Plone discussion mechanism doesn't have nice panel to administer
comments. It's hard to find new comments. It's not possible to block
posts with links or some other unwelcome contents.

But on the web there are much more specialized tools for commenting:

* `JS-Kit`_
* `DISQUS`_
* `IntenseDebate`_

This comments systems can be easily integrated with sites - user just need
to create account and add some special code into his website.

collective.disqus integrates `DISQUS`_ comment system with `Plone`_, so
installation process is even easier.

Extra Features
==============

Current version of `collective.disqus` doesn't migrate comments. So all
comments that was created before installation will be hidden (not removed).
But it includes `/@@disqus-exportcomments` form which can export Plone comments
into generic `WXR DISQUS format`_ to import it into DISQUS service. It supports
both: good old CMFCore-based comments as well as new `plone.app.discussion`
comments engine.

In case you need to make server side calls to remote DISQUS API then this
package also provides `collective.disqus.api.DisqusAPI` class which inherits
from `disqus-python`_ and fetches DISQUS settings from Plone control panel for
you, so you don't need to add it on every DISQUS API call.

This package also supports DISQUS `Single-Sign-On Addon`_. For details on it's
configuration, please, check `Configuration` section below.

Installation
============

It's only few easy steps to integrate DISQUS with your Plone site:

* create account on `DISQUS`_
* add you website in DISQUS admin panel (remember configured website short name)
* install `collective.disqus`:

  add to your buildout::

    eggs =
      collective.disqus

  use *Add products* in *Site Setup* or *QuickInstaller* to activate it

Configuration
=============

Go to *Site Setup* -> *DISQUS comment system* control panel form and configure
*Website short name*. DISQUS should be visible in all contents that enabled
commenting.

In case you have a separate public-facing theme for anonymous visitors only
and you would like to show DISQUS comments only for them, but hide it for
your content editors, check *Only display for anonymous*.

To enable SSO integration you firstly need to purchase it on DISQUS service,
then register your `DISQUS Application`_ and retrieve public and secret
application related keys. Those keys you'll need to enter into Plone DISQUS
control panel.

Optionally if you want to provide your own login/logout options on DISQUS
commenting form then, please, fill in appropriate *SSO* fields on control panel.
Details on what these all fields stand for you can find on DISQUS
`Single-Sign-On Addon`_ documentation page.

Compatibility
=============

Tested and working on Plone 3 and Plone 4 versions.

Contributors
============

Project initiated by `Wojciech Lichota`_.

Contributors:

* Wojciech Lichota [sargo]
* `Rok Garbas`_ [garbas]
* `Harald Friessnegger`_ [fRiSi]
* `Nejc Zupan`_ [zupo]
* `Vitaliy Podoba`_ [piv]

.. _DISQUS: http://disqus.com
.. _Plone: http://plone.org
.. _WXR DISQUS format: http://docs.disqus.com/developers/export/import_format
.. _Single-Sign-On Addon: http://docs.disqus.com/developers/sso
.. _disqus-python: http://pypi.python.org/pypi/disqus-python
.. _DISQUS Application: http://disqus.com/api/applications
.. _Wojciech Lichota: http://lichota.pl
.. _JS-Kit: http://js-kit.com/
.. _IntenseDebate: http://intensedebate.com/home
.. _Rok Garbas: http://www.garbas.si
.. _`Harald Friessnegger`: http://webmeisterei.com
.. _Nejc Zupan: http://www.niteoweb.com
.. _Vitaliy Podoba: vitaliypodoba@gmail.com
