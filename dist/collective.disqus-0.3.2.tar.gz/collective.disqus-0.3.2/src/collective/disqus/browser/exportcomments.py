import time
from datetime import datetime

from DateTime import DateTime

from zope.interface import Interface
from zope import schema
from zope.schema.vocabulary import SimpleVocabulary, SimpleTerm
from zope.component import queryAdapter
from zope.i18nmessageid import MessageFactory
from zope.app.pagetemplate.viewpagetemplatefile import ViewPageTemplateFile

from Products.CMFCore.utils import getToolByName
from Products.CMFPlone.utils import safe_unicode

from z3c.form import form, button, field
from plone.z3cform.layout import wrap_form, FormWrapper

try:
    from plone.app.discussion.interfaces import IConversation
    PAD_COMMENTS = True
except ImportError:
    PAD_COMMENTS = False


_ = MessageFactory('collective.disqus')

EXPORT_FORMATS = (
    {'value': 'WXR', 'title': _(u"WXR")},
)

COMMENTS_ENGINES = (
    {'value': 'cmf', 'title': _(u"CMFCore based comments")},
)

# conditionally add p.a.d option to comments engines export vocabulary
if PAD_COMMENTS:
    COMMENTS_ENGINES += (
        {'value': 'p.a.d', 'title': _(u"plone.app.discussion comments")},)


def makeVocabulary(values):
    return SimpleVocabulary([SimpleTerm(v['value'], v['value'], v['title'])
        for v in values])

def formatExportDate(value):
    """We expect here Zope2 DateTime or pytho datetime objects"""
    if isinstance(value, DateTime):
        value = "%0.4d-%0.2d-%0.2d %0.2d:%0.2d:%0.2d" % \
            value.toZone('GMT').parts()[:6]
    elif isinstance(value, datetime):
        value = value.strftime('%Y-%m-%d %H:%M:%S')
    return value

class IDisqusExportCommentsForm(Interface):
    
    comments_engine = schema.Choice(
        title=_(u"Comments Engine"),
        description=_(u"Select here comments engine you are using to store "
                      "comments on your site."),
        vocabulary=makeVocabulary(COMMENTS_ENGINES),
        default='cmf',
        required=True)
    
    export_format = schema.Choice(
        title=_(u"Export Format"),
        description=_(u"Select here comments export format from available "
                      "list. Note: WXR - "
                      "http://docs.disqus.com/developers/export/import_format"),
        vocabulary=makeVocabulary(EXPORT_FORMATS),
        default='WXR',
        required=True)
    
    sso_domain = schema.ASCIILine(
        title=_(u"SSO Domain"),
        description=_(u"In case you purchased SSO addon on DISQUS and are "
                      "willing to include sso user ids that are registered on "
                      "your plone site, please, enter here your registered SSO "
                      "Domain. Then 'dsq:remote' element will be included into "
                      "export to reference your real Plone users from DISQUS "
                      "comments."),
        default='',
        required=False)

class DisqusExportCommentsForm(form.Form):

    ignoreContext = True

    fields = field.Fields(IDisqusExportCommentsForm)
    label = 'Export Plone Comments'
    description = _(u"On this form you can export Plone comments into some of "
                    "DISQUS-aware formats.")

    _wxr_schema_template = ViewPageTemplateFile(
        'exportcomments_wxr_template.pt')

    # internal variable holding pages for export to pass from export action
    # handler to form render method
    _to_export = None

    @button.buttonAndHandler(_(u"Export"), name='export')
    def handleExport(self, action):
        data, errors = self.extractData()
        if len(errors) > 0:
            self.status = _(u"There were some errors.")
            return
        
        # check if we support selected export format
        template = None
        if data['export_format'] == 'WXR':
            template = self._wxr_schema_template
        
        if template is None:
            self.status = _(u"Uknown export format: %s" % data['export_format'])
            return
        
        # export comments
        pages = ()
        if data['comments_engine'] == 'p.a.d':
            if not PAD_COMMENTS:
                self.status = _(u"plone.app.discussion package is not "
                                "installed.")
                return
            
            pages = self._getPloneAppDiscussionComments(data)
        elif data['comments_engine'] == 'cmf':
            pages = self._getCMFComments(data)
        else:
            self.status = _(u"Export for %s comments engine is not implemented "
                            "yet." % data['comments_engine'])
            return
                
        # check if we got any comments
        if len(pages) == 0:
            self.status = _(u"No comments found.")
            return
        
        # set exported content into class level variable for render method
        # to return to outside world
        self._to_export = self._wxr_schema_template(pages=pages)
        
        # set response content type header to xml
        content_type = 'text/plain'
        ext = '.txt'
        if data['export_format'] == 'WXR':
            content_type = 'text/xml'
            ext = '.rss'
        
        # required to prompt user uploaded exported comments file
        self.request.response.setHeader('Content-Type', content_type)
        self.request.response.setHeader('Content-disposition',
            'attachment; filename=plone_comments_%s%s' % (
                time.strftime('%Y%m%d%H%M%S'), ext))
        
        self.status = _(u"Comments successfully exported.")
    
    def _getCMFComments(self, data):
        """Export old CMFCore based comments"""
        portal_discussion = getToolByName(self.context, 'portal_discussion')
        mtool = getToolByName(self.context, 'portal_membership')
        catalog = getToolByName(self.context, 'portal_catalog')
        
        sso_domain = data['sso_domain']
        pages = []
        for brain in catalog(object_provides=
                'Products.CMFCore.interfaces._content.IContentish'):
                
            # skips comments itself
            if brain.portal_type == 'Discussion Item':
                continue
                
            try:
                obj = brain.getObject()
            except Exception:
                continue
            else:
                if obj is None:
                    continue
            
            # check if we got talkback object
            talkback = getattr(obj, 'talkback', None)
            if talkback is None:
                continue
            
            def populateCommentsLevel(comments, replies):
                # recursive function to get all direct replies
                # of a comment. Returns True if there are no replies to
                # this comment left, and therefore the comment can be removed.
                if len(replies) == 0:
                    return

                for comment in replies:
                    # we use userid for sso addon
                    userid = user_image = ''
                    author_url = ''
                
                    # author name and email fields are required for DISQUS
                    # import so set placeholders anyway
                    author_name = 'Anonymous User'
                    author_email = 'anonymous@email.address.com'
                    
                    creator = comment.Creator() or ''
                    if sso_domain and creator and creator != 'Anonymous User':
                        userid = creator
                        # TODO: add url to user avatar
                        # user_image = 'http://user.image.jpg'
                        # TODO: set author url
                        # author_url = 'http://author.url'
                    
                    # if we got creator a real user then try to fetch it's
                    # full name and email address, also it's website url
                    if creator and creator != 'Anonymous User':
                        member = mtool.getMemberById(creator)
                        if member is not None:
                            author_name = safe_unicode(
                                member.getProperty('fullname') or creator)
                            author_email = safe_unicode(
                                member.getProperty('email') or
                                '%s@email.address.com' % creator)
                    
                    comments.append({
                        'userid': userid,
                        'user_image': user_image,
                        'id': str(comment.id),
                        'author_name': author_name,
                        'author_email': author_email,
                        'author_url': author_url,
                        'author_ip': '',
                        'date': formatExportDate(comment.creation_date),
                        'body': comment.text,
                        # TODO: check review state, set 0 for private comments
                        'approved': '1',
                        'parent': str(comment.in_reply_to or 0),
                    })
                    
                    # now recursively extract this comment's replies
                    talkback = getattr(comment, 'talkback', None)
                    if talkback is not None:
                        populateCommentsLevel(comments, talkback.getReplies())

                return
            
            # recursively get comments
            comments = []
            populateCommentsLevel(comments, talkback.getReplies())
            
            # no comments found here
            if len(comments) == 0:
                continue
            
            # collect page details
            pages.append({
                'title': _(safe_unicode(brain.Title)),
                'desc': safe_unicode(brain.Description),
                'url': obj.absolute_url(),
                'uid': brain.UID,
                'created': formatExportDate(obj.created()),
                'comment_status': portal_discussion.isDiscussionAllowedFor(obj)
                    and 'open' or 'closed',
                'comments': tuple(comments)
            })
        
        return tuple(pages)
    
    def _getPloneAppDiscussionComments(self, data):
        """Export plone.app.discussion based comments"""
        catalog = getToolByName(self.context, 'portal_catalog')
        sso_domain = data['sso_domain']
        pages = []
        for brain in catalog(object_provides=
                'Products.CMFCore.interfaces._content.IContentish'):
            try:
                obj = brain.getObject()
            except Exception:
                continue
            else:
                if obj is None:
                    continue
            
            conversation = queryAdapter(obj, IConversation)
            if conversation is None:
                continue
            
            comments = []
            for cdata in conversation.getThreads():
                comment = cdata['comment']
                
                # we use userid for sso addon
                userid = user_image = ''
                author_url = ''
                
                # author name and email fields are required for DISQUS import
                # so set placeholders anyway
                author_name = 'Anonymous User'
                author_email = 'anonymous@email.address.com'

                creator = comment.creator
                if sso_domain and creator and creator != 'Anonymous User':
                    userid = creator
                    # TODO: add url to user avatar
                    # user_image = 'http://user.image.jpg'
                    # TODO: set author url 
                    # author_url = 'http://author.url'
                
                # if we got creator then try to fetch it's
                # full name and email address from comment
                if creator and creator != 'Anonymous User':
                    author_name = safe_unicode(comment.author_name or creator)
                    author_email = safe_unicode(comment.author_email or 
                        '%s@email.address.com' % creator)
                
                comments.append({
                    'userid': userid,
                    'user_image': user_image,
                    'id': str(comment.comment_id),
                    'author_name': author_name,
                    'author_email': author_email,
                    'author_url': author_url,
                    'author_ip': '',
                    'date': formatExportDate(comment.creation_date),
                    'body': comment.text,
                    # TODO: check review state, set 0 for private comments
                    'approved': '1',
                    'parent': str(comment.in_reply_to or 0),
                })
            
            # no comments found here
            if len(comments) == 0:
                continue
            
            # collect page details
            pages.append({
                'title': _(safe_unicode(brain.Title)),
                'desc': safe_unicode(brain.Description),
                'url': obj.absolute_url(),
                'uid': brain.UID,
                'created': formatExportDate(obj.created()),
                'comment_status': conversation.enabled() and 'open' or 'closed',
                'comments': tuple(comments)
            })
        
        return tuple(pages)

class DisqusExportCommentsFormWrapper(FormWrapper):
    """We need to use our own plone.z3cform form wrapper to be able to
    pass exported file w/o wrapped plone template.
    """
    
    def render(self):
        """If wrapped form got exported file then return it instead of
        sending form output.
        """
        if self.form_instance._to_export is not None:
            output = self.form_instance._to_export
            self.form_instance._to_export = None
            return output
        else:
            return super(DisqusExportCommentsFormWrapper, self).render()

DisqusExportCommentsView = wrap_form(DisqusExportCommentsForm,
    __wrapper_class=DisqusExportCommentsFormWrapper)
