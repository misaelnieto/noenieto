import sys
import base64
import hmac
import simplejson
import time

# workaround due to bug: http://code.google.com/p/boto/issues/detail?id=172
try:
    from hashlib import sha1 as sha
    
    if sys.version[:3] == "2.4":
        # we are using an hmac that expects a .new() method.
        class Faker:
            def __init__(self, which):
                self.which = which
                self.digest_size = self.which().digest_size
            
            def new(self, *args, **kwargs):
                return self.which(*args, **kwargs)
        
        sha = Faker(sha)
except ImportError:
    import sha


def get_disqus_sso_message(secret_key, user):
    """Generated DISQUS SSO message based on Application
    secret key and user.
    
    @user should be dictionary with at least id, username and email
    keys. Optionally it may contain: avatar (url to user image) and
    url (url to user's website) keys.
    """
    
    # create a JSON packet of our data attributes
    data = simplejson.dumps(user)
    
    # encode the data to base64
    message = base64.b64encode(data)
    
    # generate a timestamp for signing the message
    timestamp = int(time.time())
    
    # generate our hmac signature
    sig = hmac.HMAC(secret_key, '%s %s' % (message, timestamp),
        sha).hexdigest()

    # return the sso message
    return "%(message)s %(sig)s %(timestamp)s" % dict(message=message,
        timestamp=timestamp, sig=sig)
