from plone.app.controlpanel.form import ControlPanelForm
from zope.component import adapts
from zope.schema import TextLine, Bool, ASCIILine
from zope.formlib.form import Fields
from zope.i18nmessageid import MessageFactory
from zope.interface import Interface, implements

from Products.CMFDefault.formlib.schema import ProxyFieldProperty
from Products.CMFDefault.formlib.schema import SchemaAdapterBase
from Products.CMFPlone.interfaces import IPloneSiteRoot

_ = MessageFactory('collective.disqus')


class IDisqusSettings(Interface):
    """
    Defines configurable options of collective.disqus.
    """
    forum_id = TextLine(
        title=_(u'Website short name'),
        description=_(u'This short name is used to uniquely identify your '
                        u'website on DISQUS.'),
        required=True)

    credit_link_off = Bool(
        title=_(u'Switch DISQUS credit link off'),
        description=u'',
        required=False,
        default=False)

    dev_mode = Bool(
        title=_(u'Developer mode'),
        description=_(u'Enables developer mode, which allows testing to be '
                        u'done on local, protected, or otherwise inaccessible '
                        u'servers. '),
        required=True)

    anon_only = Bool(
        title=_(u'Anonymous only'),
        description=_(u'Display DISQUS comments only for anonymous visitors '
                        u'and hide it for logged-in content editors.'),
        required=False)

    enable_sso = Bool(
        title=_(u'Enable SSO'),
        description=_(u'Enables Single-Sign-On Disqus addon integration on the '
                        u'site (http://docs.disqus.com/developers/sso).'),
        required=False,
        default=False)
    
    app_secret_key = TextLine(
        title=_(u'Application Secret Key'),
        description=_(u'This key is required for SSO feature. It could be '
                        u'retrieved by registering DISQUS application: '
                        u'http://disqus.com/api/applications.'),
        required=False,
        default=u'')
    
    app_public_key = TextLine(
        title=_(u'Application Public Key'),
        description=_(u'This key is required for SSO feature. It could be '
                        u'retrieved by registering DISQUS application: '
                        u'http://disqus.com/api/applications.'),
        required=False,
        default=u'')
    
    sso_site_name = TextLine(
        title=_(u'SSO: Site Name'),
        description=_(u'This and the next couple of SSO related fields are used'
                       u' to make DISQUS display your own site\'s login button '
                       u'together with default options (Facebook, Twitter, '
                       u'etc.) and replace default logout URL. Site Name is '
                       u'displayed in the "Post As" window.'),
        required=False,
        default=u'')
    
    sso_button = ASCIILine(
        title=_(u'SSO: Button Image URL'),
        description=_(u'Address of the image that acts as a button. This button'
                       u'appears on the login modal SSO window. Could be '
                       u'absolute or relative link. Could contain the next '
                       u'placeholders: %(portal_url)s - url to site root, '
                       u'%(object_url)s - current page url where commenting '
                       u'form is displayed.'),
        required=False,
        default='')
    
    sso_icon = ASCIILine(
        title=_(u'SSO: Icon URL'),
        description=_(u'Address of the image that appears on the login modal '
                       u'SSO tab. Favicons work well here. Could be '
                       u'absolute or relative link. Could contain the next '
                       u'placeholders: %(portal_url)s - url to site root, '
                       u'%(object_url)s - current page url where commenting '
                       u'form is displayed.'),
        required=False,
        default='')
    
    sso_login_url = ASCIILine(
        title=_(u'SSO: Login URL'),
        description=_(u'Address of your login page. The page will be opened in '
                       u'a new window and it must close itself after '
                       u'authentication is done. That is how DISQUS knows when '
                       u'it is done and reload the page. Could be absolute or '
                       u'relative link. Could contain the next placeholders: '
                       u'%(portal_url)s - url to site root, %(object_url)s - '
                       u'current page url where commenting form is displayed.'),
        required=False,
        default='')

    sso_logout_url = ASCIILine(
        title=_(u'SSO: Logout URL'),
        description=_(u'Address of your logout page. This page must redirect '
                       u'user back to the original page after logout. Could be '
                       u'absolute or relative link. Could contain the next '
                       u'placeholders: %(portal_url)s - url to site root, '
                       u'%(object_url)s - current page url where commenting '
                       u'form is displayed.'),
        required=False,
        default='')
    
    sso_width = ASCIILine(
        title=_(u'SSO: Login popup width'),
        description=_(u'Width of the login popup window, in pixels.'),
        required=False,
        default='800')
    
    sso_height = ASCIILine(
        title=_(u'SSO: Login popup height'),
        description=_(u'Height of the login popup window, in pixels.'),
        required=False,
        default='400')

class DisqusControlPanel(ControlPanelForm):
    """
    Configlet for collective.disqus.
    """
    form_fields = Fields(IDisqusSettings)
    label = _(u"DISQUS comment system")
    description = _(u'Allow to configure options required to integrate DISQUS '
                    u'comment system with Plone.')


class DisqusControlPanelAdapter(SchemaAdapterBase):
    """
    Store values of IDisqusConfiguration.
    """
    adapts(IPloneSiteRoot)
    implements(IDisqusSettings)

    forum_id = ProxyFieldProperty(IDisqusSettings['forum_id'])
    credit_link_off = ProxyFieldProperty(IDisqusSettings['credit_link_off'])
    dev_mode = ProxyFieldProperty(IDisqusSettings['dev_mode'])
    anon_only = ProxyFieldProperty(IDisqusSettings['anon_only'])
    enable_sso = ProxyFieldProperty(IDisqusSettings['enable_sso'])
    app_secret_key = ProxyFieldProperty(IDisqusSettings['app_secret_key'])
    app_public_key = ProxyFieldProperty(IDisqusSettings['app_public_key'])
    sso_site_name = ProxyFieldProperty(IDisqusSettings['sso_site_name'])
    sso_button = ProxyFieldProperty(IDisqusSettings['sso_button'])
    sso_icon = ProxyFieldProperty(IDisqusSettings['sso_icon'])
    sso_login_url = ProxyFieldProperty(IDisqusSettings['sso_login_url'])
    sso_logout_url = ProxyFieldProperty(IDisqusSettings['sso_logout_url'])
    sso_width = ProxyFieldProperty(IDisqusSettings['sso_width'])
    sso_height = ProxyFieldProperty(IDisqusSettings['sso_height'])
