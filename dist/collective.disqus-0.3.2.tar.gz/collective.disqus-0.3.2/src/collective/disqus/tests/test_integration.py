
import unittest2 as unittest

from zope.component import getUtility
from zope.schema.interfaces import IVocabularyFactory

from plone.app.viewletmanager.interfaces import IViewletSettingsStorage
from plone.app.testing import applyProfile
from plone.app.testing import TEST_USER_ID, TEST_USER_NAME
from plone.app.testing import login, logout, setRoles

from collective.disqus.viewlets.content import DisqusViewlet
from collective.disqus.browser.configlet import IDisqusSettings
from collective.disqus.testing import DISQUS_INTEGRATION_TESTING


class Test(unittest.TestCase):

    layer = DISQUS_INTEGRATION_TESTING

    def setUp(self):
        self.portal = self.layer['portal']
        self.setUpContent()

    def setUpContent(self):
        portal = self.portal
        
        # login as Manager
        setRoles(portal, TEST_USER_ID, ['Manager'])
        login(portal, TEST_USER_NAME)

        # prepare comments aware content object
        portal.invokeFactory('Document', 'page1', title=u"Page 1")
        page = portal['page1']
        page.allow_discussion = True

        # logout
        logout()
        setRoles(portal, TEST_USER_ID, ['Member'])

    def uninstall(self):
        applyProfile(self.portal, 'collective.disqus:uninstall')

    def test_displayviews(self):
        portal_types = self.layer['portal'].portal_types

        self.assertIn('disqus_summary_listing',
                      portal_types.get('Folder').view_methods)
        self.assertIn('disqus_summary_listing',
                      portal_types.get('Topic').view_methods)

        self.uninstall()

        self.assertNotIn('disqus_summary_listing',
                         portal_types.get('Folder').view_methods)
        self.assertNotIn('disqus_summary_listing',
                         portal_types.get('Topic').view_methods)

    def test_viewlets(self):
        storage = getUtility(IViewletSettingsStorage)
        skins = [skin.token for skin in getUtility(IVocabularyFactory,
                    'plone.app.vocabularies.Skins')(self.portal)]

        # plone.comments viewlet should be hidden
        for skin in skins:
            if skin in storage._hidden.keys() and \
               'plone.belowcontent' in storage._hidden[skin]:
                self.assertIn('plone.comments',
                              storage._hidden[skin]['plone.belowcontent'])

        self.uninstall()

        # plone.comments viewlet should be unhidden
        # and collective.disqus hidden
        for skin in skins:
            if skin in storage._hidden.keys() and \
               'plone.belowcontent' in storage._hidden[skin]:
                self.assertNotIn('plone.comments',
                              storage._hidden[skin]['plone.belowcontent'])
                self.assertIn('collective.disqus',
                              storage._hidden[skin]['plone.belowcontent'])

    def test_controlpanel(self):
        controlpanel = self.portal.portal_controlpanel
        self.assertEqual(controlpanel.getActionObject(
                         'Products/DisqusConfig').visible, 1)
        self.uninstall()
        self.assertEqual(controlpanel.getActionObject(
                         'Products/DisqusConfig').visible, 0)

    def test_disqus_url_in_viewlet(self):
        portal = self.portal
        page = portal['page1']

        # prepare DISQUS settings
        settings = IDisqusSettings(portal)
        settings.anon_only = False
        settings.forum_id = u'test_forum'

        # finally initialize viewlet and check if disqus_url is in output
        viewlet = DisqusViewlet(page, page.REQUEST, None, None)
        viewlet = viewlet.__of__(page)
        viewlet.update()
        self.failUnless(u"var disqus_url = '%s';" %
            page.absolute_url().decode('utf-8') in viewlet.render())
    
    def test_sso_off(self):
        portal = self.portal
        page = portal['page1']

        # prepare DISQUS settings
        settings = IDisqusSettings(portal)
        settings.anon_only = False
        settings.forum_id = u'test_forum'
        settings.enable_sso = False

        # finally initialize viewlet and check if we got all necessary pieces in
        # disqus viewlet output
        viewlet = DisqusViewlet(page, page.REQUEST, None, None)
        viewlet = viewlet.__of__(page)
        viewlet.update()
        self.failUnless(u"this.page.remote_auth_s3 = '';" in viewlet.render())
        
    def test_sso_on(self):
        portal = self.portal
        page = portal['page1']

        # prepare DISQUS settings
        settings = IDisqusSettings(portal)
        settings.anon_only = False
        settings.forum_id = u'test_forum'
        settings.enable_sso = True
        settings.app_secret_key = u'secret1'
        settings.app_public_key = u'public1'
        settings.sso_site_name = u'My Site1'
        settings.sso_login_url = '/sso_login'
        settings.sso_logout_url = '/sso_logout'

        # finally initialize viewlet and check if we got all necessary pieces in
        # disqus viewlet output
        viewlet = DisqusViewlet(page, page.REQUEST, None, None)
        viewlet = viewlet.__of__(page)
        viewlet.update()
        content = viewlet.render()
        
        self.failUnless(u"'name': 'My Site1'," in content)
        self.failUnless(u"'url': '/sso_login'," in content)
        self.failUnless(u"'logout': '/sso_logout'," in content)
        self.failUnless(u"this.page.api_key = 'public1';" in content)

    def test_credit_link_switch(self):
        portal = self.portal
        page = portal['page1']

        # prepare DISQUS settings
        settings = IDisqusSettings(portal)
        settings.anon_only = False
        settings.forum_id = u'test_forum'
        settings.credit_link_off = False

        # finally initialize viewlet and check if we got all necessary pieces in
        # disqus viewlet output
        viewlet = DisqusViewlet(page, page.REQUEST, None, None)
        viewlet = viewlet.__of__(page)
        viewlet.update()
        content = viewlet.render()
        
        self.failUnless(u'class="dsq-brlink"' in content)

        # now switch credit link off
        settings.credit_link_off = True
        viewlet.update()
        content = viewlet.render()
        self.failIf(u'class="dsq-brlink"' in content)

def test_suite():
    suite = unittest.TestSuite()
    suite.addTest(unittest.makeSuite(Test))
    return suite
