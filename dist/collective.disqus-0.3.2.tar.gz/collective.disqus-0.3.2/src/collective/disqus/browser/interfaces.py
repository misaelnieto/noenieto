from zope.interface import Interface
from plone.theme.interfaces import IDefaultPloneLayer

try:
    from plone.app.discussion.interfaces import IDiscussionLayer
except ImportError:
    IDiscussionLayer = Interface

class IDisqusLayer(IDefaultPloneLayer, IDiscussionLayer):
   """A layer specific to collective.disqus product.
   """
